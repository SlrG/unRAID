**ProFTPd**

Is a highly configurable GPL-licensed FTP server software.
