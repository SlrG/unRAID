<?PHP
# =========================================================================
## Load current config file and check if program is installed already
# =========================================================================

# Setup page variables
$appname="ProFTPd";
$displayname="ProFTPd";
$appexecutable="proftpd";
$appconfigfile="proftpd.conf";
$commonDIR="/usr/local/SlrG-Common";

# This will clean any ^M characters caused by windows from the config file before use
if (file_exists("/boot/config/plugins/{$appname}/{$appname}.cfg"))
	shell_exec("sed -i 's!\r!!g' \"/boot/config/plugins/{$appname}/{$appname}.cfg\"");
if (file_exists("/etc/rc.d/rc.{$appname}"))
	shell_exec("sed -i 's!\r!!g' \"/etc/rc.d/rc.{$appname}\"");

# Check existence of files
$app_cfg = parse_ini_file( "/boot/config/plugins/{$appname}/{$appname}.cfg" );
$app_installed = file_exists( "{$commonDIR}/usr/local/sbin/{$appexecutable}" ) ? "yes" : "no";
$machine_type = trim(shell_exec( "uname -m" ));
$app_rollback = file_exists( "boot/config/plugins/{$appname}.plg.old" ) ? "yes" : "no";

# =========================================================================
## Collect local variables from config files and verify data as best as possible
# =========================================================================

# Check for forcecheck, this overrides the checkonline option
if ($machine_type == "x86_64") {
	if (isset($_POST["forcecheck"])) {
		$forcecheck = $_POST["forcecheck"];
	} else {
		$forcecheck = "no";
	}
} else {
	if (isset($GLOBALS["forcecheck"])) {
		$forcecheck = $GLOBALS["forcecheck"];
	} else {
		$forcecheck = "no";
	}
}

# See if plugin is allowed to check online for latest updates on GUI load
if (isset($app_cfg['CHECKONLINE']) && ($app_cfg['CHECKONLINE'] == "yes" || $app_cfg['CHECKONLINE'] == "no")) {
	$app_checkonline=$app_cfg["CHECKONLINE"];
} else {
	$app_checkonline="yes";
}

# Check if there is internet conneciton so page doesn't stall out, only check if CHECKONLINE is allowed
if ($app_checkonline == "yes" || $forcecheck == "yes") {
	$connected = @fsockopen("www.google.com", 80, $errno, $errstr, 5);
	if ($connected){
		$is_conn = "true";
		fclose($connected);
	} else {
		$is_conn = "false";
	}
} else {
	$is_conn = "false";
}

# Plugin Current Version Variable
if (file_exists("/boot/config/plugins/{$appname}.plg")) {
	$app_plgver = trim(shell_exec ( "grep 'ENTITY plgVersion' /boot/config/plugins/{$appname}.plg | sed -n 's!.*\"\(.*\)\".*!\\1!p'" ));
	if ($app_plgver == "") {
		$app_plgver = "Unknown plugin version";
	}
} else {
	$app_plgver = "(Plugin File Missing)";
}

# Get latest release of the plugin
if ($is_conn == "true") {
	$REPO2="https://github.com/SlrG/unRAID/raw/master/Versions";
	$app_newversionPLG = trim(shell_exec ( "wget -qO- --no-check-certificate $REPO2 | sed -n 's/ProFTPd: \(.*\)/\\1/p'" ));
} else {
	$app_newversionPLG = "";
}

# Service Status Variable
if (isset($app_cfg['SERVICE']) && ($app_cfg['SERVICE'] == "enable" || $app_cfg['SERVICE'] == "disable"))
	$app_service = $app_cfg['SERVICE'];
else
	$app_service = "disable";

# Webserver Variable
if (isset($app_cfg['WEBSRV']) && ($app_cfg['WEBSRV'] == "enable" || $app_cfg['WEBSRV'] == "disable"))
	$web_server = $app_cfg['WEBSRV'];
else
	$web_server = "disable";

# WPath Variable
if (isset($app_cfg['WPATH'])) {
	$web_path = $app_cfg['WPATH'];
} else {
	$web_path = "";
}

# WPort Number Variable
if (isset($app_cfg['WPORT']) && is_numeric($app_cfg['WPORT'])) {
	$web_port = $app_cfg['WPORT'];
	if ($web_port < 0 || $web_port > 65535)
		$web_port = "8088";
} else {
	$web_port = "8088";
}

# =========================================================================
## Check is program is installed and running to get extra information
# =========================================================================
if ($app_installed=="yes") {
	$app_running = trim(shell_exec( "[ -f /proc/`cat /var/run/{$appname}/{$appname}.pid 2> /dev/null`/exe ] && echo 'yes' || echo 'no' 2> /dev/null" ));
	if ($app_running == "yes")
		$app_updatestatus = "Running";
	else
		$app_updatestatus = "Stopped";

	# Get current installed version of the program
	if ($app_running == "yes" || $is_conn == "true") {
		$app_curversion = trim(shell_exec ( "/etc/rc.d/rc.{$appname} currentversion" ));
	}
	if ($app_curversion == "")
		$app_curversion = "(Failed to detect version)";
}

# Get plugin version current and new
if ($app_newversionPLG != "" && $app_newversionPLG != $app_plgver )
	$app_canupdatePLG = "yes";
else
	$app_canupdatePLG = "no";
?>

<!-- ========================================================================= -->
<!-- Create the HTML code used to display the settings GUI -->
<!-- ========================================================================= -->
<div style="width: 49%; float:left">
	<div id="title">
		<span class="left"><img src="/plugins/<?=$appname;?>/icons/device_status.png">&#32;Status:
			<?if ($app_installed=="yes"):?>
				<?if ($app_running=="yes"):?>
					<span class="green"><b>RUNNING</b></span>
					<span style="font-size:12px;"> with version: <b><?=$app_curversion?></b></span>
				<?else:?>
					<span class="red"><b>STOPPED</b></span>
				<?endif;?>
			<?else:?>
				<span class="red"><b>NOT INSTALLED</b></span>
			<?endif;?>
		</span>
	</div>
	<?if ($app_installed=="yes"):?>
		<?if ($app_running=="yes"):?>
			<div style="position:relative;float:left;width:50%;text-align:right; margin-bottom:24px">
				<form name="app_start_stop" method="POST" action="/update.htm" target="progressFrame">
					<input type="hidden" name="cmd" value="/etc/rc.d/rc.<?=$appname?> stop"/>
					<input type="submit" name="runCmd" value="Stop"/>
				</form>
			</div>
			<div style="position:relative;float:left;width:50%;margin-bottom:24px">
				<form name="app_restart" method="POST" action="/update.htm" target="progressFrame">
					<input type="hidden" name="cmd" value="/etc/rc.d/rc.<?=$appname?> restart"/>
					<input type="submit" name="runCmd" value="Restart"/>
				</form>
			</div>
		<?else:?>
			<div style="position:relative;float:left;width:100%;text-align:center;margin-bottom:24px">
				<form name="app_start" method="POST" action="/update.htm" target="progressFrame">
					<input type="hidden" name="cmd" value="/etc/rc.d/rc.<?=$appname?> buttonstart"/>
					<input type="submit" name="runCmd" value="Start"/>
				</form>
			</div>
		<?endif;?>
	<?else:?>
		<div style="position:relative;float:left;width:100%;text-align:center;margin-bottom:24px">
			<form name="app_install" method="POST" action="/update.htm" target="progressFrame">
				<input type="hidden" name="cmd" value="/etc/rc.d/rc.<?=$appname?> install"/>
				<input type="submit" name="runCmd" value="Install"/>
			</form>
		</div>
	<?endif;?>
	<div id="title">
		<span class="left"><img src="/plugins/<?=$appname?>/icons/information.png">&#32;Information:</span>
	</div>
	<p style="margin-left:10px;"><b>Plugin Version: <?=$app_plgver;?></b></p>
	<? if ($is_conn == "false" && ($app_checkonline == "yes" || $forcecheck == "yes")):?>
		<p style="color:red;margin-left:10px;"><b>No Internet Connection Detected</b></p>
	<? endif; ?>
	<? if ($app_rollback=="yes"):?>
		<div style="position:relative;float:left;width:49%;text-align:right;margin-bottom:24px">
			<form name="app_downgrade" method="POST" action="/update.htm" target="progressFrame">
				<input type="hidden" name="cmd" value="/etc/rc.d/rc.<?=$appname?> downgradeplg"/>
				<input type="submit" name="runCmd" value="Downgrade Plugin"
					onclick="return confirm('Pressing OK will install the previous backup of this plugin.')"/>
			</form>
		</div>
		<div style="position:relative;float:right;width:49%;text-align:left;margin-bottom:24px">
			<form id="app_uninstall" method="POST" action="/update.htm" target="progressFrame">
				<input type="hidden" name="cmd" value="/etc/rc.d/rc.<?=$appname?> removeplg"/>
				<input type="submit" name="runCmd" value="Uninstall Plugin"
					onclick="return confirm('Pressing OK will remove this plugin, including all support files, dependencies and settings! Backup your proftpd.conf if you want to keep it!')"/>
			</form>
		</div>
	<?else:?>
		<div style="position:relative;float:left;width:100%;text-align:center;margin-bottom:24px">
			<form id="app_uninstall" method="POST" action="/update.htm" target="progressFrame">
				<input type="hidden" name="cmd" value="/etc/rc.d/rc.<?=$appname?> removeplg"/>
				<input type="submit" name="runCmd" value="Uninstall Plugin"
					onclick="return confirm('Pressing OK will remove this plugin, including all support files, dependencies and settings! Backup your proftpd.conf if you want to keep it!')"/>
			</form>
		</div>
	<?endif;?>
	<?if ($app_canupdatePLG=="yes"):?>
		<div style="position:relative;float:left;width:100%;text-align:center;margin-bottom:24px">
			<form name="app_update1" method="POST" action="/update.htm" target="progressFrame">
				<input type="hidden" name="cmd" value="/etc/rc.d/rc.<?=$appname?> updateplg"/>
				<input id="updatebutton" type="submit" name="runCmd" value="Update Plugin"/>
			</form><br>
			<b><?echo "Update Plugin to Version: $app_newversionPLG";?>&emsp;</b>
		</div>
	<?endif;?>
	<? if ($app_checkonline=="no" && $forcecheck != "yes"):?>
		<div style="position:relative;float:left;width:100%;text-align:center;">
			<form method="POST" action="">
				<input type="hidden" id="forcecheck" name="forcecheck" value="yes"/>
				<input type="submit" id="updatebutton" value="Manual Update Check"/>
			</form>
		</div>
	<?endif;?>
</div>
<div style="width: 49%; float:right">
	<div id="title">
		<span class="left"><img src="/plugins/<?=$appname?>/icons/new_config.png">&#32;Configuration:</span>
	</div>
	<form name="app_settings" method="POST" action="/update.htm" target="progressFrame">
		<input type="hidden" name="cmd" value="/etc/rc.d/rc.<?=$appname?>"/>
		<table class="settings">
			<tr>
				<td>Enable <?echo $displayname;?>:</td>
				<td>
					<select name="arg1" size="1">
						<?=mk_option($app_service, "disable", "No");?>
						<?=mk_option($app_service, "enable", "Yes");?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Webserver available:</td>
				<td>
					<select name="arg2" size="1" onchange="checkENABLED(document.app_settings);">
						<?=mk_option($web_server, "disable", "No");?>
						<?=mk_option($web_server, "enable", "Yes");?>
					</select>
				</td>
			</tr>
			<tr>
				<td>Webserver Path:</td>
				<td><input type="text" name="arg3" style="width:250px" maxlength="60" value="<?=$web_path;?>"/></td>
			</tr>
			<tr>
				<td>Webserver Port:</td>
				<td><input type="text" name="arg4" style="width:250px" maxlength="5" value="<?=$web_port;?>"/></td>
			</tr>
		</table><br>
		<div align="center">
			<input type="submit" name="runCmd" value="Apply" style="margin-bottom:8px" onClick="verifyDATA(this.form);"/>
			<button type="button" style="margin-bottom:35px" onClick="done();">Cancel</button>
		</div>
	</form>
</div>
<div id="footer2">
	Support the plugin? <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=TBVJLE525C5SJ" target="_blank"><img src="/plugins/<?=$appname?>/icons/paypal.gif"></a>
</div>
<?if ($web_server=="enable"):?>
  <div id="title">
    <span class="left">Edit proftpd.conf:&#32;<img src='/plugins/<?=$appname;?>/icons/new_config.png'></span>
    <span style="float: right; padding-right:15px;">
      <a href="http://www.proftpd.org/docs/howto/" target="_blank">ProFTPd mini-HOWTOs</a>
    </span>
  </div>
  <div style="padding-left:5px; padding-right:15px;">
    <iframe src="http://<?=$var['NAME'];?>:<?=$web_port;?>/<?=$appname;?>/ConfEdit.php" width="100%"
      height="420" name="ProFTPdConfig">
      <p>IFrame not supported.</p>
    </iframe>
  </div>
<?else:?>
  <div style="position:relative;float:left;width:100%;text-align:right; margin-bottom:24px">
    <span></span>
  </div>
<?endif;?>

<!-- ========================================================================= -->
<!-- Javascript functions to verify data, and perform other GUI related tasks -->
<!-- ========================================================================= -->
<script type="text/javascript">
	function checkENABLED(form) {
		if (form.arg2.options[0].selected == true) {
			form.arg3.disabled = true;
			form.arg4.disabled = true;
		} else {
			form.arg3.disabled = false;
			form.arg4.disabled = false;
		}
	}

	function verifyDATA(form) {
		form.arg2.disabled = false;
		form.arg3.disabled = false;
		form.arg4.disabled = false;
		if (isNumber(form.arg4.value)){
			if (form.arg4.value < 0 || form.arg4.value > 65535){
				form.arg4.value = "8088";
			}
		} else {
			form.arg4.value = "8088";
		}
	}

	function isNumber(n) {
		return !isNaN(parseFloat(n)) && isFinite(n);
	}

	checkENABLED(document.app_settings);
</script>
